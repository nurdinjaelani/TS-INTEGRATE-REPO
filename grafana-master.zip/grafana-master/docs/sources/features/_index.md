+++
title = "Features"
description = "List of features"
type = "docs"
[menu.docs]
name = "Features"
identifier = "features"
weight = 4
+++

# Grafana features

This section contains pages that describe Grafana features.
