+++
title = "Administration"
description = "Administration"
type = "docs"
[menu.docs]
name = "Administration"
identifier = "admin"
weight = 2
+++

# Administration

This section provides resources for Grafana administrators and users performing administrative tasks.
