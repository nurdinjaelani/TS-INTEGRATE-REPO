+++
title = "Guides"
type = "docs"
[menu.docs]
name = "Getting Started"
identifier = "guides"
weight = 3
+++

# Guides

This section contains guides to help you use Grafana.